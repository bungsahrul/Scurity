""" Configuration file """

# Variable to configure
TOKEN_ID = 'Your token_id'
CHAT_ID = 'Your chat_id'

# Default duration for video recording in seconds
VIDEO_TIME = 60

# Path of the folder where the videos and photos are stored
REGISTRATION_FOLDER = 'tmp/video'
