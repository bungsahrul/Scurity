# Security Policy

## Reporting a Vulnerability

Please report (suspected) security vulnerabilities to
**[moby.31412@gmail.com](mailto:moby.31412@gmail.com)**. You will receive a response from within 72 hours. If the issue is confirmed, i will release a patch as soon
as possible depending on complexity but historically within a few days.
